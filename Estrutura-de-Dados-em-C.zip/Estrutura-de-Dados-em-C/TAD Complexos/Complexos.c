#include <stdio.h>
#include <stdbool.h>

#define MAX_PASSAGEIROS 30
#define MAX_COMPARTIMENTOS 10

typedef struct {
    int codigo;
    char nome[50];
    int peso;
    bool preferencial;
    bool despachada;
} Mala;

typedef struct {
    Mala malas[MAX_COMPARTIMENTOS];
    int ocupados;
} preferencial;

typedef struct {
    preferencial prioritario;
    preferencial naoPrioritario;
} Filas;

void inicializarFilas(Filas *filas) {
    filas->prioritario.ocupados = 0;
    filas->naoPrioritario.ocupados = 0;
}

void adicionarMala(Filas *filas, Mala mala) {
    if (mala.preferencial && filas->prioritario.ocupados < MAX_COMPARTIMENTOS) {
        filas->prioritario.malas[filas->prioritario.ocupados] = mala;
        filas->prioritario.ocupados++;
    } else if (filas->naoPrioritario.ocupados < MAX_COMPARTIMENTOS) {
        filas->naoPrioritario.malas[filas->naoPrioritario.ocupados] = mala;
        filas->naoPrioritario.ocupados++;
    } else {
        printf("Não há espaço nos compartimentos para a mala de %s.\n", mala.nome);
        if (mala.preferencial) {
            printf("Cliente preferencial. Bônus de R$100,00 gerado.\n");
            mala.peso += 100;
        }
        else {
            printf("Cliente não preferencial. Mala será despachada.\n");
            mala.despachada = true;
        }
    }
}

void imprimirMalas(Filas filas) {
    printf("Processo de entrega das malas:\n");
    for (int i = 0; i < filas.prioritario.ocupados; i++) {
        Mala mala = filas.prioritario.malas[i];
        printf("Nome do passageiro: %s\n", mala.nome);
        printf("Código da mala: %d\n", mala.codigo);
        printf("Status: Preferencial\n");
        printf("Peso da mala: %d kg\n", mala.peso);
        if (mala.preferencial && mala.despachada) {
            printf("Bônus de R$100,00 gerado.\n");
        }
        printf("------------------------\n");
    }
    for (int i = 0; i < filas.naoPrioritario.ocupados; i++) {
        Mala mala = filas.naoPrioritario.malas[i];
        printf("Nome do passageiro: %s\n", mala.nome);
        printf("Código da mala: %d\n", mala.codigo);
        printf("Status: Não preferencial\n");
        printf("Peso da mala: %d kg\n", mala.peso);
        if (mala.preferencial && mala.despachada) {
            printf("Bônus de R$100,00 gerado.\n");
        }
        printf("------------------------\n");
    }
}

int main() {
    Filas filas;
    inicializarFilas(&filas);
    
    Mala mala1 = {1, "P1", 5, false, true};
    Mala mala2 = {2, "P2", 10, true, true};
    Mala mala3 = {3, "P3", 5, true, true};
    Mala mala4 = {4, "P4", 10, true, true};
    Mala mala5 = {5, "P5", 10, true, true};
    Mala mala6 = {6, "P6", 10, true, true};
    Mala mala7 = {7, "P7", 5, true, true};
    Mala mala8 = {8, "P7", 10, true, true};
    Mala mala9 = {9, "P7", 5, true, true};
    Mala mala10 = {10, "P7", 10, true, true};
    Mala mala11 = {11, "P7", 5, true, false};
    
    adicionarMala(&filas, mala1);
    adicionarMala(&filas, mala2);
    adicionarMala(&filas, mala3);
    adicionarMala(&filas, mala4);
    adicionarMala(&filas, mala5);
    adicionarMala(&filas, mala6);
    adicionarMala(&filas, mala7);
    adicionarMala(&filas, mala8);
    adicionarMala(&filas, mala9);
    adicionarMala(&filas, mala10);
    adicionarMala(&filas, mala11);
    
    imprimirMalas(filas);
    
    return 0;
}
