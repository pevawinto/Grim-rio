#include <stdio.h>

void bubbleSort(int vetor[], int tamanho) {
  int i, j, temp;
  
  for (i = 0; i < tamanho-1; i++) {
    for (j = 0; j < tamanho-i-1; j++) {
      if (vetor[j] > vetor[j+1]) {
        // Troca os elementos de posição
        temp = vetor[j];
        vetor[j] = vetor[j+1];
        vetor[j+1] = temp;
      }
    }
    
    // Imprime o vetor resultante após cada passo do processo de ordenação
    printf("Passo %d: ", i+1);
    for (int k = 0; k < tamanho; k++) {
      printf("%d ", vetor[k]);
    }
    printf("\n");
  }
}

int main() {
  int vetor[] = {41, 23, 16, 2, 52, 39, 9, 16};
  int tamanho = sizeof(vetor) / sizeof(vetor[0]);
  
  printf("Vetor original: ");
  for (int i = 0; i < tamanho; i++) {
    printf("%d ", vetor[i]);
  }
  printf("\n\n");
  
  bubbleSort(vetor, tamanho);
  
  printf("\nVetor ordenado: ");
  for (int i = 0; i < tamanho; i++) {
    printf("%d ", vetor[i]);
  }
  printf("\n");
  
  return 0;
}
