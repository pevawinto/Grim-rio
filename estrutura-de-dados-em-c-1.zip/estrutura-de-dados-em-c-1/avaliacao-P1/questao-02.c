#include <stdio.h>


int main() {

    int x;
    printf("%ld \n", sizeof(x));
    printf("%ld \n", sizeof(char));
    printf("%ld \n", sizeof(int));
    printf("%ld \n", sizeof(int*));
    printf("%ld \n", sizeof(char**));

}