#include "deque_como_vetor.h"
#include <stdio.h>
#include <stdlib.h> 


int main() { 
    
   printf("\n--- Deque como Vetor ---\n\n");
     
   
   return 0;

}