#include "arvore_patricia_trie.h" 
#include <stdio.h>


