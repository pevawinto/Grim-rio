#include "arvore_patricia_trie.h"
#include <stdio.h>
#include <stdlib.h> 


int main() { 
    
   printf("\n--- Árvore Digital de Busca, Tries e Patricia Tries ---\n\n");
   
 
   return 0;

}