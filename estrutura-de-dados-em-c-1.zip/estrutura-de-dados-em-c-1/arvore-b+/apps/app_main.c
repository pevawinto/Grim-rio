#include "arvore_b+.h"
#include <stdio.h>
#include <stdlib.h> 


int main() { 
    
   printf("\n--- Árvore B, B* e B+ ---\n\n");
   
 
   return 0;

}