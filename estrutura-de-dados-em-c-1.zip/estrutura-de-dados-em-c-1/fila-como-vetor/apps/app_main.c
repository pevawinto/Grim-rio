#include "fila_como_vetor.h"
#include <stdio.h>
#include <stdlib.h> 


int main() { 
    
   printf("\n--- FILA -  ---\n\n");
    
   
   return 0;
}