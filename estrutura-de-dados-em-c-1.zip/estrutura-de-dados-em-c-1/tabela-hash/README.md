## Tabela Hash


---

