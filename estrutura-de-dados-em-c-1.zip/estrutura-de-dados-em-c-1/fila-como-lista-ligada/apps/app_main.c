#include "fila_como_lista_ligada.h"
#include <stdio.h>
#include <stdlib.h> 


int main() { 
    
   printf("\n--- Fila como Lista Ligada ---\n\n");

   
   return 0;

}