#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void printf_vetor(int *vetor  , int n);

void printf_heap(int *vetor);

void heap_sort(int *vet, int n);
