#include "deque_como_lista_ligada.h"
#include <stdio.h>
#include <stdlib.h> 


int main() { 
    
   printf("\n--- Deque como Lista Ligada ---\n\n");
     
   
   return 0;

}